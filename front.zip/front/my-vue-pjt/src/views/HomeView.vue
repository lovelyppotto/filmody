<template>
    <div>
        <h1>홈입니다</h1>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>