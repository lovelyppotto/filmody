<template>
    <MovieList />
</template>

<script setup>
import MovieList from '@/components/MovieList.vue';
</script>

<style scoped>

</style>